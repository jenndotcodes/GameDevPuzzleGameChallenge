package com.fifteenpuzzle

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LifecycleOwner
import com.fifteenpuzzle.databinding.MainActivityBinding
import java.util.Collections.shuffle
import java.util.stream.IntStream
import kotlin.streams.toList

class MainActivity : AppCompatActivity(), LifecycleOwner {
    private lateinit var binding: MainActivityBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = MainActivityBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

    }


}